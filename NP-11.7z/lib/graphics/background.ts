/// <reference path="../index.ts" />

namespace Vidya.Graphics {
    export class Background extends Vidya.Graphics.Base {
        public constructor(canvas: HTMLCanvasElement) {
            super(canvas);
        }

        public clear(): void {

        }

        public draw(): void {

        }
    }
}

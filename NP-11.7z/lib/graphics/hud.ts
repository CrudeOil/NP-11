/// <reference path="../index.ts" />

namespace Vidya.Graphics {
    export class Hud extends Vidya.Graphics.Base {
        public clear(): void {
            throw new Error("Method not implemented.");
        }
        public draw(): void {
            throw new Error("Method not implemented.");
        }
    }
}

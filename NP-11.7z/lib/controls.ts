/// <reference path="./index.ts" />

namespace Game {
    export class Controls {

    }
}
